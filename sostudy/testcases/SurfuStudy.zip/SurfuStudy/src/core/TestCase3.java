package core;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class TestCase3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
		Set<String> myStr = new HashSet<String>();
        myStr.add("obj1");
        Iterator itr = myStr.iterator();
        Method mtd = itr.getClass().getMethod("hasNext");
        System.out.println(mtd.invoke(itr, args));
		}catch(Exception exc)
		{
			exc.printStackTrace();
		}
	}
}
