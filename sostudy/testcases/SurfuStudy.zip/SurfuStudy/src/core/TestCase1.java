package core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestCase1 {

	/**
	 * @param args
	 */
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> myList = new ArrayList<String>();
		String[] fruits={"orange","apple","banana","mango","guava","lemon"};
        //adding items to the list
		for(String fruit:fruits){
        	myList.add(fruit);
        }
        
        //finding an item and deleting it
		try{
		Iterator<String> it = myList.iterator();
        while(it.hasNext()){
            String value = it.next();   
            if(value.equals("mango")) myList.remove(value);
        }}catch(Exception exc){
        	exc.printStackTrace();
        }
	}
}
