package core;

import java.io.File;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class TestCase5 {

	/**
	 * @param args
	 */
	
	public static void execute()
	{
		try
		{
			@SuppressWarnings("deprecation")
			URL url = new File("./data/test.txt").toURL();
			URLConnection connection = url.openConnection();
			connection.setDoOutput(true);
			OutputStream output = connection.getOutputStream();
		}catch(Exception exc)
		{
			exc.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			@SuppressWarnings("deprecation")
			URL url = new File("./data/test.txt").toURL();
			URLConnection connection = url.openConnection();
			connection.setDoOutput(true);
			OutputStream output = connection.getOutputStream();
		}catch(Exception exc)
		{
			exc.printStackTrace();
		}
	}

}
