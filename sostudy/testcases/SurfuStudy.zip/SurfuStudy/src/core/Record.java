package core;

public class Record {
	String firstName;
	String lastName;
}
