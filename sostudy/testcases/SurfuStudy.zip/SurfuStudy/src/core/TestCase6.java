package core;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestCase6 {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text = "Fri Jan 10 15:26:49 CST 2014";
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        try {
            Date parsed = sdf.parse(text.trim());
            System.out.println(parsed);
        } catch (ParseException e) {
            e.printStackTrace();
        };

	}

}
