package core;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class TestCase4 {

	/**
	 * @param args
	 */
	
	public static void execute()
	{
		try
	    {
	        Socket client = new Socket("localhost", 1238);
	        ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
	        out.flush();
	        ObjectInputStream in = new ObjectInputStream(client.getInputStream());
	        System.out.println("Buffer size: " + client.getSendBufferSize());
	 
	        for (int i = 0 ; i < 10 ; i++)
	        {
	 
	        if ( i == 3 )
	        {
	            Thread.currentThread().interrupt();
	            System.out.println("Interrupted.");
	        }
	        out.writeObject("From Client: Hellow." + i);
	        out.flush();
	        System.out.println(in.readObject());
	        }
	         
	    }catch(Exception exc)
	    {
	    	exc.printStackTrace();
	    }
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
	    {
	        Socket client = new Socket("localhost", 1238);
	        ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
	        out.flush();
	        ObjectInputStream in = new ObjectInputStream(client.getInputStream());
	 
	        System.out.println("Buffer size: " + client.getSendBufferSize());
	 
	        for (int i = 0 ; i < 10 ; i++)
	        {
	 
	        if ( i == 3 )
	        {
	            Thread.currentThread().interrupt();
	            System.out.println("Interrupted.");
	        }
	        out.writeObject("From Client: Hellow." + i);
	        out.flush();
	        System.out.println(in.readObject());
	        }
	         
	    }catch(Exception exc)
	    {
	    	exc.printStackTrace();
	    }
	}

}
