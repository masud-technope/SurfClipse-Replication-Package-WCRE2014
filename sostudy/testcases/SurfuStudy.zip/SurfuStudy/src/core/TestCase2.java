package core;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class TestCase2 {

	/**
	 * @param args
	 */
	
	public static void execute()
	{
		try
		{
		 String fileName="./data/testcase2.txt";
		 FileInputStream fis = new FileInputStream(new File(fileName));  
         ObjectInputStream ois = new ObjectInputStream(fis);  
         ArrayList<Record>currentList = new ArrayList<Record>();  
         //restore the number of objects  
         int size = ois.readInt();  
         for (int i=0; i<size; i++) {  
             Record current = (Record) ois.readObject();  
             currentList.add(current);  
         }  
		}catch(Exception exc){
			exc.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		 String fileName="./data/testcase2.txt";
		 FileInputStream fis = new FileInputStream(new File(fileName));  
         ObjectInputStream ois = new ObjectInputStream(fis);  
         ArrayList<Record>currentList = new ArrayList<Record>();  
         //restore the number of objects  
         int size = ois.readInt();  
         for (int i=0; i<size; i++) {  
             Record current = (Record) ois.readObject();  
             currentList.add(current);  
         }  
		}catch(Exception exc){
			exc.printStackTrace();
		}
	}

}
